#ifdef CLUSTERER_SHARED_EXPORTS
    #ifdef _WIN32
        #define CLUSTERER_SHARED_API __declspec(dllexport)
    #else
        #define CLUSTERER_SHARED_API __attribute__((visibility("default")))
    #endif
    
#elif CLUSTERER_STATIC
    #define CLUSTERER_SHARED_API
#else
    #ifdef _WIN32
        #define CLUSTERER_SHARED_API __declspec(dllimport)
    #else
        #define CLUSTERER_SHARED_API
    #endif
#endif