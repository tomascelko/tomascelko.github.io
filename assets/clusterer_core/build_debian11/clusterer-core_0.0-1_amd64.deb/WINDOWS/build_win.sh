#!/bin/bash

# Install CUDA 12.6 using Chocolatey
CUDA_VERSION="12.6.0.560"
CUDA_VERSION_SHORT="v12.6"

df -h
du -ah /mnt/c/Users | sort -rh | head -n 10

echo "Listing all choco cache files:" 
ls -al "C:/ProgramData/chocolatey/lib"
#choco upgrade chocolatey -y
#choco install choco-cleaner -y
#choco-cleaner -y
#choco install cuda -y # -dv --version=${CUDA_VERSION} -y

# Get all available drives in Windows
#drives=$(cmd.exe /c "wmic logicaldisk get name" | findstr /R "^[A-Z].:" | tr -d '\r' | xargs)

drives="c/" 
# Iterate through each drive and search for nvcc.exe
for drive in $drives; do
if [ -n "$drive" ]; then
    #echo "Searching in unformatted $drive ..."
    # Convert Windows drive letter (e.g., C:) to Bash path (e.g., /c)
    #bash_drive=$(echo "$drive" | tr '[:upper:]' '[:lower:]' | sed 's/:/\/g')

    echo "Searching in $drive ..."
    
    # Search for nvcc.exe in the current drive
    nvcc_path=$(find "$drive" -type f -name "nvcc.exe" 2>/dev/null)
    
    if [ -n "$nvcc_path" ]; then
        echo "nvcc found at: $nvcc_path"
        exit 0
    fi
    fi
done

# If not found, print a message
echo "nvcc not found on any available drive."


# Define the CUDA installation path
export CUDA_PATH=$(dirname $(which nvcc))/..

# Check if the CUDA 12.6 directory exists
if [ ! -d "$CUDA_PATH" ]; then
    echo "CUDA not found. Installation may have failed."

    exit 1
fi

echo "Detected CUDA version: $CUDA_VERSION"

# Set up the CUDA environment by adding paths
export PATH="$CUDA_PATH/bin;$CUDA_PATH/lib/x64;$PATH"
export CUDATOOLKITDIR="$CUDA_PATH"

echo "CUDA PATH: $CUDA_PATH"
echo "CUDATOOLKITDIR: $CUDATOOLKITDIR"
echo "Updated PATH: $PATH"

# Verify nvcc installation
echo "CHECKING NVCC VERSION:"
nvcc --version || { echo "nvcc not found in PATH"; exit 1; }

# Prepare build output directory
build_output_dir="./build"
build_output_dir=$(echo "$build_output_dir" | sed 's|\\|/|g') # Normalize path for Windows compatibility
mkdir -p "$build_output_dir"

# Run CMake configuration
echo "Running CMake configuration..."
cmake -B "$build_output_dir" \
      -DCMAKE_CXX_COMPILER=cl \
      -DCMAKE_C_COMPILER=cl \
      -DCMAKE_BUILD_TYPE=Release \
      -S "." || { echo "CMake configuration failed"; exit 1; }

# Build the project
echo "Building the project..."
cmake --build "$build_output_dir" --config Release || { echo "Build failed"; exit 1; }

echo "Build completed successfully."
