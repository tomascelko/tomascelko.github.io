
GITHUB_USER=tomascelko
mkdir -p assets/clusterer_core
echo "About to copy following files:"
ls clusterer-core-artifacts
cp -r clusterer-core-artifacts/* assets/clusterer_core/


echo "Cloning GitHub repository..."
git clone https://${GITHUB_USER}:${CELKO_PAGE_PAT}@github.com/${GITHUB_USER}/${GITHUB_USER}.github.io.git
cd ${GITHUB_USER}.github.io

echo "Copying file to GitHub repository..."
ls 
ls ../build_*
#TBD to be updated to include windows files
cp -r ../build_* assets/clusterer_core

echo "Committing and pushing changes..."
git add assets/clusterer_core
git commit -m "automated update: deployment from GitLab CI/CD"
git push origin main