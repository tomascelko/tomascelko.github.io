#!/bin/bash
CUDA_VERSION="12.6"
echo "Setting up CUDA environment for ${CUDA_VERSION}"
export CUDA_PATH=${CUDA_PATH_PREFIX}/cuda-${CUDA_VERSION}

echo "CUDA PATH: ${CUDA_PATH}"

BUILD_DIR="build_${OS_TAG}"
export PATH="${PATH}:${CUDA_PATH}/bin"
echo "PATH: ${PATH}"
export LD_LIBRARY_PATH="$CUDA_PATH/lib64:${LD_LIBRARY_PATH}"
echo "LD PATH: ${LID_LIBRARY_PATH}"

CUDA_VERSION_STR=$(echo "$CUDA_VERSION" | tr '.' '-')

apt-get update
apt-get install sudo
sudo apt-get update
sudo apt-get install -y build-essential devscripts dpkg-dev fakeroot debhelper
sudo apt-get install dh-cmake

echo "Installing CUDA Toolkit"
wget https://developer.download.nvidia.com/compute/cuda/repos/${OS_TAG}/x86_64/cuda-keyring_1.1-1_all.deb

sudo dpkg -i cuda-keyring_1.1-1_all.deb

# Check if "deb" is present in the OS_TAG
if [[ "${OS_TAG}" == *"deb"* ]]; then
    sudo add-apt-repository contrib
fi

sudo apt-get update

echo "Installing CUDA Toolkit version: cuda-toolkit-${CUDA_VERSION_STR}"
sudo apt-get -y install cuda-toolkit-${CUDA_VERSION_STR}
nvcc --version   
echo "Configuring and building with CMake"
cmake -B ${BUILD_DIR} -DCMAKE_CXX_COMPILER=g++ -DCMAKE_C_COMPILER=gcc -DCMAKE_BUILD_TYPE=Release -S .
cmake --build ${BUILD_DIR} --config Release   
echo "Organizing artifacts"
mkdir -p ${BUILD_DIR}/artifacts/clusterer_core/lib
cp -r ${BUILD_DIR}/*.a ${BUILD_DIR}/*.so ${BUILD_DIR}/artifacts/clusterer_core/lib

cp -r include ${BUILD_DIR}/artifacts/clusterer_core/

mkdir -p cicd/deb/usr/
cp -r include cicd/deb/usr
mkdir -p cicd/deb/usr/lib
cp -r ${BUILD_DIR}/*.a ${BUILD_DIR}/*.so cicd/deb/usr/lib

zip -r ${BUILD_DIR}/clusterer_core.zip ${BUILD_DIR}/artifacts/clusterer_core

chmod -R 0755 cicd/deb/DEBIAN
cd cicd/deb
dpkg-deb --build . clusterer_core_amd64.deb
cp clusterer_core_amd64.deb ../../${BUILD_DIR}