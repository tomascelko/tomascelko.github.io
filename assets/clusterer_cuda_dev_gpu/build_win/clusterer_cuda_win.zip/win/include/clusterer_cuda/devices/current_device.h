#include "timepix3.h"
#pragma once
namespace clustering
{
    // currently used chip
    class current_chip
    {
    public:
        using chip_type = timepix3;
    };
}