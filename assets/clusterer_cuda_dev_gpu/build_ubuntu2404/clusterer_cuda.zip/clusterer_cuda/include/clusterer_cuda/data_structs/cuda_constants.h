#pragma once
#include <cstdint>
struct cuda_constants
{
    uint64_t TOA_NS_MULTIPLIER;
    uint64_t MAX_CLUSTER_JOIN_TIME;
    uint64_t MAX_HIT_COUNT;
    uint32_t APPROX_HITS_PER_WORKER;
    uint32_t MATRIX_SIZE;
    uint32_t MATRIX_HEIGHT;
    uint32_t MATRIX_WIDTH;
    uint32_t TOTAL_THREAD_COUNT;
    uint32_t PADDED_MATRIX_WIDTH;
    uint16_t DFU_THREADS_PER_BLOCK;
    uint16_t INIT_DFU_THREADS_PER_BLOCK;
    uint32_t DFU_BLOCK_COUNT;
    uint32_t LABEL_CACHE_SIZE;
    uint32_t LABEL_CACHE_MIDPOINT;
    uint32_t HIT_DATA_CACHE_SIZE;
    bool ONLINE_CONTRACT_DFU_PATH;
    bool USE_LABEL_CACHE_NORMAL;
    bool USE_LABEL_CACHE_BORDER;
    uint16_t TILE_SIZE;

};