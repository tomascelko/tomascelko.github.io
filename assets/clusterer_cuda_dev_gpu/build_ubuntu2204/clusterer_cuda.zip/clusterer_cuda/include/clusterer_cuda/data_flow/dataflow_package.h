// a package which includes basic headers reuqired for managing the dataflow
// and implementing a node
#pragma once
#include "external_dataflow_controller.cuh"
#include "i_data_node.h"