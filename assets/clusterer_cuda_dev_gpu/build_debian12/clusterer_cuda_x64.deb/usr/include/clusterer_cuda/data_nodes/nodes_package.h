// a file to simplify including of headers in code which builds architectures
// from multiple nodes
#pragma once
#include "clustering/external_cuda_clusterer.cuh"
#include "io/external_data_reader.cuh"