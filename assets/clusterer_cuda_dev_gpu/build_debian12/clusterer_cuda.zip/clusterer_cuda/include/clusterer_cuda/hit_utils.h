#pragma once
#include "data_structs/tpx3_hit.h"
#include "data_structs/tpx4_hit.h"

template <typename T>
struct wide_toa_type;  // primary template (incomplete, to trigger errors if misused)

template <>
struct wide_toa_type<tpx3_hit> {
    using type = tpx3_hit64;
};

template <>
struct wide_toa_type<tpx4_hit> {
    using type = tpx4_hit64;
};